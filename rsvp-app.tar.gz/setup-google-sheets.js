/**
 * Setup Google Sheets Integration
 * 
 * This script helps you configure the Google Sheets integration
 */

const fs = require('fs');
const path = require('path');

class GoogleSheetsSetup {
    constructor() {
        this.envPath = path.join(__dirname, '.env');
    }

    async setup() {
        console.log('🚀 Setting up Google Sheets Integration...\n');
        
        try {
            await this.checkEnvFile();
            await this.promptForGoogleAppsScriptURL();
            console.log('\n✅ Google Sheets integration setup complete!');
            console.log('\n📋 Next steps:');
            console.log('1. Follow the instructions in GOOGLE_APPS_SCRIPT_SETUP.md');
            console.log('2. Create your Google Apps Script and get the web app URL');
            console.log('3. Update the GOOGLE_APPS_SCRIPT_URL in your .env file');
            console.log('4. Restart your app');
        } catch (error) {
            console.error('❌ Setup failed:', error.message);
        }
    }

    async checkEnvFile() {
        console.log('🔍 Checking .env file...');
        
        if (!fs.existsSync(this.envPath)) {
            console.log('⚠️  .env file not found. Creating one...');
            const defaultEnv = `# Google Drive API Configuration
GOOGLE_CLIENT_ID=317952139039-eb0m52pb4ismluq3ujh964n72ftaa8u6.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback

# Server Configuration
PORT=4000
NODE_ENV=development

# App Configuration
APP_URL=http://localhost:4000

# Google Apps Script URL (for RSVP form submissions)
GOOGLE_APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec
`;
            fs.writeFileSync(this.envPath, defaultEnv);
            console.log('✅ Created .env file with default configuration');
        } else {
            console.log('✅ .env file found');
        }
    }

    async promptForGoogleAppsScriptURL() {
        console.log('\n📝 Google Apps Script Configuration:');
        console.log('To complete the setup, you need to:');
        console.log('1. Go to https://script.google.com/');
        console.log('2. Create a new project');
        console.log('3. Copy the code from GOOGLE_APPS_SCRIPT_SETUP.md');
        console.log('4. Deploy as a web app');
        console.log('5. Copy the web app URL');
        console.log('6. Update GOOGLE_APPS_SCRIPT_URL in your .env file');
        
        // Check if the URL is already set
        const envContent = fs.readFileSync(this.envPath, 'utf8');
        if (envContent.includes('YOUR_SCRIPT_ID')) {
            console.log('\n⚠️  You still need to update GOOGLE_APPS_SCRIPT_URL in your .env file');
        } else {
            console.log('\n✅ Google Apps Script URL appears to be configured');
        }
    }
}

// Run setup if this file is executed directly
if (require.main === module) {
    const setup = new GoogleSheetsSetup();
    setup.setup();
}

module.exports = GoogleSheetsSetup;
